This is my final project for the cse111 course. I made a small mp3 player using vlc media player.

Requirements:
Through pip:
  python-vlc
  pytest

on PC:
  vlc media player

mp3 files in the songs folder

The file structure requires the songs, playlist folder and test_files folder to be in the same directory as the mp3_player.py and test_mp3_player.py
https://github.com/Jejedi11/final_project.git
